<?php

class Emarka_Storesms_Model_Resource_Storesms extends Mage_Core_Model_Resource_Db_Abstract {


    public function _construct() {
        $this->_init("storesms/storesms","id");

    }


}

